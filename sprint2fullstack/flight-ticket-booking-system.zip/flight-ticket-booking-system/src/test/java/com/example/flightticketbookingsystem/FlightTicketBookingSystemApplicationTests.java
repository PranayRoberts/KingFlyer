package com.example.flightticketbookingsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightTicketBookingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
